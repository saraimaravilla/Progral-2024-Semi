﻿namespace sistema_academico.Models {
    public class AlumnoBusquedaParametros {
        public string? buscar { get; set; }
    }
}
