﻿namespace sistema_academico.Models {
    public class DocenteBusquedaParametros {
        public string? buscar { get; set; }
    }
}
